CREATE TABLE uzytkownik
(
    uzytkownik_id       SERIAL PRIMARY KEY,
    haslo               VARCHAR(256) NOT NULL,
    nick                VARCHAR(256) NOT NULL,
    imie                VARCHAR(256) NOT NULL,
    nazwisko            VARCHAR(256) NOT NULL,
    email               VARCHAR(256) NOT NULL,
    data_rejestracji    TIMESTAMP NOT NULL DEFAULT NOW(),
    miasto              VARCHAR(256) DEFAULT NULL
);

CREATE TABLE ogrod
(
    ogrod_id        SERIAL PRIMARY KEY,
    uzytkownik_id   INTEGER REFERENCES uzytkownik NOT NULL,
    nazwa           VARCHAR(256) NOT NULL,
    data_zalozenia  TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE grzadka
(
    grzadka_id  SERIAL PRIMARY KEY,
    nazwa       VARCHAR(256) NOT NULL
);

CREATE TABLE pole
(
    pole_id     SERIAL PRIMARY KEY,
    ogrod_id    INTEGER REFERENCES ogrod NOT NULL,
    grzadka_id  INTEGER REFERENCES grzadka NOT NULL,
    x           INTEGER NOT NULL,
    y           INTEGER NOT NULL
);

CREATE TABLE roslina
(
    roslina_id  SERIAL PRIMARY KEY,
    nazwa       VARCHAR(256) NOT NULL
);

CREATE TABLE produkt
(
    produkt_id  SERIAL PRIMARY KEY,
    nazwa       VARCHAR(256) NOT NULL
);

CREATE TABLE roslina_produkcja
(
    roslina_produkcja_id    SERIAL PRIMARY KEY,
    roslina_id              INTEGER REFERENCES roslina NOT NULL,
    produkt_id              INTEGER REFERENCES produkt NOT NULL
);

CREATE TABLE posadzenie
(
    posadzenie_id       SERIAL PRIMARY KEY,
    roslina_id          INTEGER REFERENCES roslina NOT NULL,
    pole_id             INTEGER REFERENCES pole NOT NULL,
    data_posadzenia     TIMESTAMP NOT NULL DEFAULT NOW(),
    data_zakonczenia    TIMESTAMP
);

CREATE TABLE posadzenie_produkcja
(
    posadzenie_produkcja_id SERIAL PRIMARY KEY,
    posadzenie_id           INTEGER REFERENCES posadzenie NOT NULL,
    produkt_id              INTEGER REFERENCES produkt NOT NULL,
    data_produkcji          TIMESTAMP NOT NULL DEFAULT NOW(),
    liczebnosc              INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE sklep
(
    sklep_id    SERIAL PRIMARY KEY,
    nazwa       VARCHAR(256) NOT NULL,
    adres       VARCHAR(256)
);

CREATE TABLE produkt_magazyn
(
    produkt_magazyn_id      SERIAL PRIMARY KEY,
    uzytkownik_id           INTEGER REFERENCES uzytkownik NOT NULL,
    produkt_id              INTEGER REFERENCES produkt NOT NULL,
    liczebnosc              INTEGER NOT NULL DEFAULT 1,
    data_produkcji_zakupu   TIMESTAMP NOT NULL DEFAULT NOW(),
    data_waznosci           TIMESTAMP,
    posadzenie_id           INTEGER REFERENCES posadzenie,
    sklep_id                INTEGER REFERENCES sklep,
    cena                    INTEGER DEFAULT NULL,
    CONSTRAINT valid        CHECK((sklep_id IS NOT NULL AND posadzenie_id IS NULL) OR (sklep_id IS NULL AND posadzenie_id IS NOT NULL))
);

CREATE TABLE zabieg
(
    zabieg_id                   SERIAL PRIMARY KEY,
    posadzenie_id               INTEGER REFERENCES posadzenie NOT NULL,
    nazwa                       VARCHAR(256) NOT NULL,
    efektywnosc                 INTEGER NOT NULL DEFAULT 100,
    czestotliwosc_wykonywania   VARCHAR(512)
);

CREATE TABLE zabieg_wykorzystanie
(
    zabieg_wykorzystanie_id     SERIAL PRIMARY KEY,
    zabieg_id                   INTEGER REFERENCES zabieg NOT NULL,
    produkt_magazyn_id          INTEGER REFERENCES produkt_magazyn NOT NULL
);
